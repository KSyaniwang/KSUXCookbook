// Scroll progress bar
const progressBar = document.getElementById('scroll-progress-bar');
window.addEventListener('scroll', () => {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const progress = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
    if (progressBar) progressBar.style.width = `${progress}%`;
});

// Scroll to top
const scrollTopBtn = document.getElementById('scroll-top');
window.addEventListener('scroll', () => {
    scrollTopBtn?.classList.toggle('visible', window.scrollY > 300);
});
scrollTopBtn?.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Fade-in on scroll
const fadeObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, { threshold: 0.1 });

document.querySelectorAll('.fade-in').forEach(el => fadeObserver.observe(el));

// Journey map interactivity
const journeyStepData = {
    1: {
        title: 'Homepage',
        userAction: 'User lands on the homepage and sees large promotional banners, search, and “Shop For” category shortcuts.',
        whatWorks: 'The homepage is visually engaging and gives users multiple entry points into discovery.',
        whereItBreaks: 'The promotional banner creates an expectation that tapping it will lead to relevant campaign products or product details. Instead, the journey feels less direct and may take users into a broader browsing path. For users with a specific skin concern, the homepage does not clearly guide whether they should search, browse categories, or follow promotions.'
    },
    2: {
        title: 'Collections',
        userAction: 'User enters Collections and browses product groups such as Skin Concerns, Cleansers, Toners, and Treatments.',
        whatWorks: 'The category structure helps users understand the product range and supports browsing by product type.',
        whereItBreaks: 'There is no search entry within Collections. If users are browsing categories but then want to look for a specific concern, ingredient, or product, they need to go back to the homepage or another screen to search. This interrupts the discovery flow.'
    },
    3: {
        title: 'Search',
        userAction: 'User goes back to search for a specific need, such as “after sun.”',
        whatWorks: 'The app shows preview results, which helps users quickly see whether their query is relevant.',
        whereItBreaks: 'Search feels separated from category browsing. Users cannot easily move between guided category discovery and keyword search. If the search returns no results or weak results, there is little support for alternative suggestions, related categories, or spelling recovery.'
    },
    4: {
        title: 'Product listing',
        userAction: 'User taps to see more results and enters a product listing page.',
        whatWorks: 'The listing page exposes more options and includes sorting/filtering controls, which is important for comparing products.',
        whereItBreaks: 'Users may need stronger signals to decide what fits them, such as skin type, concern match, ingredient highlights, bestseller tags, or “recommended for you” labels.'
    },
    5: {
        title: 'Product detail',
        userAction: 'User opens a product detail page to review price, rating, description, and add-to-cart option.',
        whatWorks: 'The add-to-cart path is clear. The product image, price, rating, and CTA are visible, which helps move the user closer to purchase.',
        whereItBreaks: 'The page could do more to build skincare confidence: when to use it, who it is for, what concern it solves, and whether it fits the user’s skin type or routine.'
    },
    6: {
        title: 'Cart',
        userAction: 'User adds the product and reaches the cart.',
        whatWorks: 'The cart clearly shows selected items, price, discount, and checkout CTA.',
        whereItBreaks: 'Cart is not the main friction in this audit. The bigger issue happens earlier: users need to find and trust the right product before they reach this point.'
    }
};

function buildJourneyAuditContent(data) {
    return `
        <div class="journey-audit__section">
            <h5 class="journey-audit__label">User action</h5>
            <p class="journey-audit__text">${data.userAction}</p>
        </div>
        <div class="journey-audit__section">
            <h5 class="journey-audit__label">What works</h5>
            <p class="journey-audit__text">${data.whatWorks}</p>
        </div>
        <div class="journey-audit__section">
            <h5 class="journey-audit__label">Where it breaks</h5>
            <p class="journey-audit__text">${data.whereItBreaks}</p>
        </div>`;
}

function showJourneyStep(stepId) {
    document.querySelectorAll('.journey-screen').forEach(screen => {
        const isActive = parseInt(screen.dataset.step, 10) === stepId;
        screen.classList.toggle('active-journey-screen', isActive);
        screen.setAttribute('aria-pressed', String(isActive));
    });

    const data = journeyStepData[stepId];
    const titleEl = document.getElementById('detail-title');
    const contentEl = document.getElementById('detail-content');
    const container = document.getElementById('details-container');

    if (titleEl) titleEl.textContent = data.title;
    if (contentEl) contentEl.innerHTML = buildJourneyAuditContent(data);

    if (container) {
        container.style.opacity = '0.5';
        container.style.transform = 'translateY(4px)';
        setTimeout(() => {
            container.style.opacity = '1';
            container.style.transform = 'translateY(0)';
        }, 50);
    }
}

document.querySelectorAll('.journey-screen').forEach(screen => {
    screen.addEventListener('click', () => {
        const stepId = parseInt(screen.dataset.step, 10);
        showJourneyStep(stepId);
    });
});

showJourneyStep(1);

// Issue audit grid
const issueAuditData = [
    {
        id: 1,
        screenTitle: 'Homepage',
        image: 'assets/journey/01-homepage.png',
        layout: 'flow',
        markers: [
            {
                id: 1, top: 28, left: 50,
                severity: 'medium',
                text: 'Too many discovery paths compete on the same screen. The skin quiz, promotions, Shop For categories, free gifts, new arrivals, and brand/social cards all have value, but they are not clearly prioritized. The promotional banners are visually dominant, but the destination is not always predictable. When I tap a promotion, I expect to see relevant campaign products or product details. If it leads into a broader category path, the interaction feels slightly mismatched.'
            },
            {
                id: 2, top: 65, left: 50,
                severity: 'medium',
                text: 'The “Shop For” section gives useful category shortcuts, but users only see part of the category set at first. This can make discovery feel limited, especially if the user does not already know they can scroll.'
            },
            {
                id: 3, top: 11, left: 50,
                severity: 'medium',
                text: 'For users who already know what they want, the search bar works well. But for users who are browsing or trying to understand their skin needs, the homepage could make the guidance stronger.'
            }
        ],
        analysis: [
            'The homepage already offers many ways to discover products. This is useful because different users may enter with different intentions and the homepage needs to expose many selling points at once.'
        ],
        improve: [
            'I would keep the richness of the homepage, but organize it more clearly around user intent.',
            'I would add a lightweight category navigation bar near the top of the homepage, below the search bar or hero banner. This keeps the commercial homepage structure, but makes the discovery logic easier to understand.'
        ]
    },
    {
        id: 2,
        screenTitle: 'Collections',
        image: 'assets/journey/02-collections.png',
        layout: 'flow',
        markers: [
            {
                id: 1, top: 26, left: 50,
                severity: 'high',
                text: 'We can have the user flow as looking for after sun. Since it is more of a skin concern, I would naturally go into Skin Concerns. But once I do not find anything directly related to after sun, I want to search from there. The problem is that search is not available inside this category context, so I need to go back to the homepage and use the main search bar.'
            },
            {
                id: 2, top: 55, left: 50,
                severity: 'high',
                text: 'The category cards are clear, but the structure is quite static. Once users enter Collections, they cannot easily refine their intent through search.'
            }
        ],
        analysis: [
            'When the user enters Collections, they see many categories, this is useful because skincare users often browse by category instead of knowing an exact product name.'
        ],
        improve: [
            'I would add a contextual search bar inside Collections. This would make Collections feel more flexible and would help users recover when the category label does not match their own wording.'
        ]
    },
    {
        id: 3,
        screenTitle: 'Search',
        image: 'assets/journey/03-search.png',
        layout: 'flow',
        markers: [],
        analysis: [
            'After going back to the homepage and searching “after sun,” the app shows preview results. This is a good part of the experience because users can quickly scan whether the results are relevant before entering a full product listing. If the user wants to see more, they can tap “show more” and move into the product listing page.'
        ],
        improve: [
            'I would keep the search preview because it is useful, but make search accessible from more places, especially Collections and product listing pages.',
            'I would also add related suggestions when the query is broad or unclear, such as: Products, Related categories, Related concerns, etc. (all of the things should be added based on the ux research). This would make search more supportive for skincare users who may not know the exact product term.'
        ]
    },
    {
        id: 4,
        screenTitle: 'Product listing',
        image: 'assets/journey/04-product-listing.png',
        layout: 'flow',
        markers: [
            {
                id: 1, top: 42, left: 50,
                severity: 'high',
                text: 'The main issue is product card consistency. Some product cards communicate ingredients, some communicate usage, and some communicate product type or target area, such as eyes. The information is useful, but because it changes from card to card, comparison becomes harder.'
            }
        ],
        analysis: [
            'The product listing page is one of the stronger parts of the flow. Product images are large and clear, which makes browsing feel visually pleasant. The product listing follows a standard e-commerce pattern: show a broad catalog first, then let users sort and filter. This makes sense for a skincare retailer with many SKUs and brands.'
        ],
        improve: [
            'I would standardize product cards so every card shows the same core decision information.',
            'the things will be based on the ux research to decide which one should go upfront.',
            'This would make the listing page easier to scan and compare.'
        ]
    },
    {
        id: 5,
        screenTitle: 'Product detail',
        image: 'assets/journey/05-product-detail.png',
        layout: 'flow',
        markers: [
            {
                id: 1, top: 60, left: 58,
                severity: 'medium',
                text: 'There are some visual inconsistencies. Left and right padding does not always align, typography sizes vary, and there are many different combinations of font size, color, bold text, and regular text on the same page.'
            },
            {
                id: 2, top: 90, left: 50,
                severity: 'medium',
                text: 'Some text sections also feel plain and not designed enough, especially on information-heavy pages.'
            }
        ],
        analysis: [
            'After selecting a product, the product detail page gives users the key purchase information and add-to-cart. The add-to-cart action is clear, and the page also has recent reviews, and the swipe interaction is consistent with other carousel-style sections in the app.'
        ],
        improve: [
            'I would create a cleaner product detail structure with consistent spacing, simplified typography, and scannable sections like Key benefits, Ingredients, How to use, and Reviews.'
        ]
    },
    {
        id: 6,
        screenTitle: 'Cart',
        image: 'assets/journey/06-cart.png',
        layout: 'flow',
        markers: [
            {
                id: 1, top: 22, left: 50,
                severity: 'medium',
                text: 'The visual importance of "Go to cart" and "Checkout" is basically the same, which is confusing, especially because users are already on the cart page.'
            },
            {
                id: 2, top: 52, left: 22,
                severity: 'medium',
                text: 'Several things do not align consistently, and the page uses too many font sizes and colors. Some icons, such as the cart illustration and wishlist heart, also do not match the app\'s style.'
            }
        ],
        analysis: [
            'The cart clearly shows selected items, price, discount, and checkout. Once users reach this point, the path to purchase is straightforward.'
        ],
        improve: [
            'The UX in this flow is not the most important thing. The path to checkout is already clear.',
            'I would focus improvements on the design system: clearer CTA hierarchy between "Go to cart" and "Checkout", consistent typography and color usage, better alignment, and icons that match the rest of the app.'
        ]
    }
];

if (typeof assetUrl === 'function') {
    issueAuditData.forEach(item => {
        if (item.image) item.image = assetUrl(item.image);
    });
}

function severityLabel(severity) {
    return severity === 'high' ? 'High severity' : 'Medium severity';
}

function renderFlowPanelFull(audit) {
    const analysisHtml = audit.analysis.map(p => `<p class="issue-audit__text">${p}</p>`).join('');
    const improveHtml = audit.improve?.length
        ? audit.improve.map(p => `<p class="issue-audit__text">${p}</p>`).join('')
        : '';
    const hasMarkers = audit.markers?.length > 0;
    const calloutHtml = hasMarkers
        ? `<div class="issue-audit__callout" data-callout>
                <p class="issue-audit__text issue-audit__callout-hint">Click a numbered marker on the screen to see the issue.</p>
           </div>`
        : '';
    const improveBlockHtml = audit.improve?.length
        ? `<div class="issue-audit__block">
            <h4 class="issue-audit__label">What I would do</h4>
            ${improveHtml}
        </div>`
        : '';

    return `
        <div class="issue-audit__block">
            <h4 class="issue-audit__label">Analysis</h4>
            ${analysisHtml}
            ${calloutHtml}
        </div>
        ${improveBlockHtml}`;
}

function renderSeverityTag(severity) {
    if (severity !== 'high') return '';
    return '<span class="issue-audit__severity-tag">High severity</span>';
}

function renderFlowCallout(marker) {
    if (!marker) {
        return '<p class="issue-audit__text issue-audit__callout-hint">Click a numbered marker on the screen to see the issue.</p>';
    }
    return `
        ${renderSeverityTag(marker.severity)}
        <p class="issue-audit__text issue-audit__callout-text">${marker.text}</p>`;
}

function showFlowMarker(auditEl, markerId) {
    const auditId = parseInt(auditEl.dataset.audit, 10);
    const audit = issueAuditData.find(a => a.id === auditId);
    const marker = audit?.markers?.find(m => m.id === markerId);
    if (!marker) return;

    auditEl.querySelectorAll('.issue-marker--clickable').forEach(btn => {
        btn.classList.toggle('active', parseInt(btn.dataset.marker, 10) === markerId);
    });

    const callout = auditEl.querySelector('[data-callout]');
    if (callout) callout.innerHTML = renderFlowCallout(marker);
}

function renderIssuePanel(hotspot) {
    return `
        <div class="issue-audit__severity issue-audit__severity--${hotspot.severity}">
            <span class="issue-audit__severity-dot"></span>
            ${severityLabel(hotspot.severity)}
        </div>
        <h3 class="issue-audit__issue-title">${hotspot.title}</h3>
        <div class="issue-audit__section">
            <h4 class="issue-audit__label">Problem</h4>
            <p class="issue-audit__text">${hotspot.problem}</p>
        </div>
        <div class="issue-audit__section">
            <h4 class="issue-audit__label">Improve</h4>
            <p class="issue-audit__text">${hotspot.improve}</p>
        </div>`;
}

function showIssueHotspot(auditEl, hotspotId) {
    const data = issueAuditData.find(a => a.id === parseInt(auditEl.dataset.audit, 10));
    const hotspot = data?.hotspots.find(h => h.id === hotspotId);
    if (!hotspot) return;

    auditEl.querySelectorAll('.issue-hotspot').forEach(btn => {
        btn.classList.toggle('active', parseInt(btn.dataset.hotspot, 10) === hotspotId);
    });

    const panel = auditEl.querySelector('.issue-audit__panel');
    if (panel) panel.innerHTML = renderIssuePanel(hotspot);
}

function buildIssueAudit(audit) {
    const isFlow = audit.layout === 'flow';

    const markersHtml = isFlow
        ? (audit.markers || []).map(m => `
            <button type="button" class="issue-marker issue-marker--clickable" data-marker="${m.id}" style="top:${m.top}%;left:${m.left}%;" aria-label="Annotation ${m.id}">${m.id}</button>
        `).join('')
        : (() => {
            const first = audit.hotspots[0];
            return audit.hotspots.map(h => `
                <button type="button" class="issue-hotspot${h.id === first.id ? ' active' : ''}" data-hotspot="${h.id}" style="top:${h.top}%;left:${h.left}%;" aria-label="Issue ${h.id}: ${h.title}">${h.id}</button>
            `).join('');
        })();

    const panelHtml = isFlow
        ? renderFlowPanelFull(audit)
        : renderIssuePanel(audit.hotspots[0]);

    const screenContent = isFlow
        ? `<div class="issue-audit__device">
                <img src="${audit.image}" alt="${audit.screenTitle} audit screen" class="issue-audit__image"/>
                ${markersHtml}
           </div>`
        : `<img src="${audit.image}" alt="${audit.screenTitle} audit screen" class="issue-audit__image issue-audit__image--full"/>
           ${markersHtml}`;

    return `
        <article class="issue-audit${isFlow ? ' issue-audit--flow' : ''} fade-in" data-audit="${audit.id}">
            <div class="issue-audit__inner">
                <div class="issue-audit__screen${isFlow ? '' : ' issue-audit__screen--legacy'}">
                    ${screenContent}
                    <span class="issue-audit__screen-title">${audit.screenTitle}</span>
                </div>
                <div class="issue-audit__panel">
                    ${panelHtml}
                </div>
            </div>
        </article>`;
}

function initIssueAudits() {
    const grid = document.getElementById('issue-audits-grid');
    if (!grid) return;

    grid.innerHTML = issueAuditData.map(buildIssueAudit).join('');

    grid.querySelectorAll('.issue-audit').forEach(auditEl => {
        const auditId = parseInt(auditEl.dataset.audit, 10);
        const audit = issueAuditData.find(a => a.id === auditId);

        if (audit?.layout === 'flow') {
            auditEl.querySelectorAll('.issue-marker--clickable').forEach(btn => {
                btn.addEventListener('click', () => {
                    showFlowMarker(auditEl, parseInt(btn.dataset.marker, 10));
                });
            });
            return;
        }

        auditEl.querySelectorAll('.issue-hotspot').forEach(btn => {
            btn.addEventListener('click', () => {
                showIssueHotspot(auditEl, parseInt(btn.dataset.hotspot, 10));
            });
        });
    });

    grid.querySelectorAll('.fade-in').forEach(el => fadeObserver.observe(el));
}

initIssueAudits();

// Prototype modal
const protoModal = document.getElementById('prototype-modal');
const protoClose = document.getElementById('prototype-close');

protoClose?.addEventListener('click', () => protoModal?.classList.remove('open'));
protoModal?.addEventListener('click', (e) => {
    if (e.target === protoModal) protoModal.classList.remove('open');
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') protoModal?.classList.remove('open');
});

// Roadmap phase interactivity
const roadmapPhases = document.querySelectorAll('.roadmap-phase');

roadmapPhases.forEach((phase, index) => {
    phase.addEventListener('click', () => {
        roadmapPhases.forEach(p => p.classList.remove('active'));
        phase.classList.add('active');
    });
    if (index === 0) phase.classList.add('active');
});

// Sub-nav within UX Review
const subNavLinks = document.querySelectorAll('.sub-nav-link');
subNavLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        subNavLinks.forEach(l => l.classList.remove('text-primary', 'font-bold'));
        link.classList.add('text-primary', 'font-bold');
    });
});

// Persona accordions (interactive only, skip static personas)
document.querySelectorAll('.persona-accordion:not(.persona-accordion--static)').forEach(accordion => {
    const trigger = accordion.querySelector('.persona-trigger');
    trigger?.addEventListener('click', () => {
        const isOpen = accordion.classList.contains('open');
        accordion.classList.toggle('open', !isOpen);
        trigger.setAttribute('aria-expanded', String(!isOpen));
    });
});

// Metric accordions
document.querySelectorAll('.metric-accordion').forEach(accordion => {
    const trigger = accordion.querySelector('.metric-trigger');
    const content = accordion.querySelector('.metric-content');
    if (!trigger || !content) return;

    const measureContentHeight = () => {
        content.style.maxHeight = 'none';
        const height = content.scrollHeight;
        return height;
    };

    const setExpanded = (expanded) => {
        accordion.classList.toggle('open', expanded);
        trigger.setAttribute('aria-expanded', String(expanded));

        if (expanded) {
            const height = measureContentHeight();
            content.style.maxHeight = '0px';
            requestAnimationFrame(() => {
                content.style.maxHeight = `${height}px`;
            });
        } else {
            content.style.maxHeight = '0px';
        }
    };

    trigger.addEventListener('click', () => {
        setExpanded(!accordion.classList.contains('open'));
    });

    window.addEventListener('resize', () => {
        if (accordion.classList.contains('open')) {
            content.style.maxHeight = `${measureContentHeight()}px`;
        }
    });
});

// Design system card detail panel
function dsSpecFigure(image, alt) {
    const src = typeof assetUrl === 'function' ? assetUrl(image) : image;
    return `
        <figure class="ds-spec-figure">
            <img src="${src}" alt="${alt}" class="ds-spec-figure__img" loading="lazy" decoding="async"/>
        </figure>`;
}

function dsBtnComp({ token, label, btnClass, btnText, hint, specImage, specAlt, props }) {
    const propsHtml = props.map(row => `<div><dt>${row[0]}</dt><dd>${row[1]}</dd></div>`).join('');
    const stageContent = specImage
        ? dsSpecFigure(specImage, specAlt || label)
        : `
                <button type="button" class="ds-spec-btn ${btnClass}">${btnText}</button>
                ${hint ? `<p class="ds-btn-comp__hint">${hint}</p>` : ''}`;
    const stageClass = specImage ? 'ds-btn-comp__stage ds-btn-comp__stage--figure' : 'ds-btn-comp__stage';

    return `
        <div class="ds-btn-comp">
            <div class="ds-btn-comp__head">
                <code>${token}</code>
                <span>${label}</span>
            </div>
            <div class="${stageClass}">
                ${stageContent}
            </div>
            <dl class="ds-btn-comp__props">${propsHtml}</dl>
        </div>`;
}

function dsCompSpec({ token, label, context, specImage, specAlt, stageClass = '', props }) {
    const propsHtml = props.map(row => `<div><dt>${row[0]}</dt><dd>${row[1]}</dd></div>`).join('');
    return `
        <div class="ds-comp-spec">
            <div class="ds-comp-spec__head">
                <code>${token}</code>
                <span>${context}</span>
            </div>
            <div class="ds-comp-spec__stage ds-comp-spec__stage--figure${stageClass ? ` ${stageClass}` : ''}">
                ${dsSpecFigure(specImage, specAlt || label)}
            </div>
            <dl class="ds-btn-comp__props">${propsHtml}</dl>
        </div>`;
}

const designSystemPanels = {
    typography: {
        title: 'Typography & spacing',
        html: `
            <div class="ds-spec">
                <div class="ds-spec__block">
                    <div class="ds-spec__block-head">
                        <p class="ds-spec__block-title">Type scale</p>
                        <p class="ds-spec__block-note">Plus Jakarta Sans · prototype screens</p>
                    </div>
                    <div class="ds-spec__block-body">
                        <div class="ds-spec-type">
                            <span class="ds-spec-type__sample" style="font-size:20px;line-height:28px;font-weight:700;">Skin Concerns</span>
                            <div class="ds-spec-type__meta"><strong>title-lg</strong><code>20px / 28px / 700</code></div>
                        </div>
                        <div class="ds-spec-type">
                            <span class="ds-spec-type__sample" style="font-size:16px;line-height:24px;font-weight:700;">Final Price €18.55</span>
                            <div class="ds-spec-type__meta"><strong>title-md</strong><code>16px / 24px / 700</code></div>
                        </div>
                        <div class="ds-spec-type">
                            <span class="ds-spec-type__sample" style="font-size:15px;line-height:20px;font-weight:500;">Purchase the products you saved during the session.</span>
                            <div class="ds-spec-type__meta"><strong>body-lg</strong><code>15px / 20px / 500</code></div>
                        </div>
                        <div class="ds-spec-type">
                            <span class="ds-spec-type__sample" style="font-size:14px;line-height:20px;font-weight:600;">Madagascar Centella Light Cleansing Oil</span>
                            <div class="ds-spec-type__meta"><strong>body-md-semibold</strong><code>14px / 20px / 600</code></div>
                        </div>
                        <div class="ds-spec-type">
                            <span class="ds-spec-type__sample ds-spec-type__sample--muted" style="font-size:14px;line-height:20px;font-weight:500;">Cart Total</span>
                            <div class="ds-spec-type__meta"><strong>body-md</strong><code>14px / 20px / 500</code><code>color #6b7280</code></div>
                        </div>
                        <div class="ds-spec-type">
                            <span class="ds-spec-type__sample ds-spec-type__sample--brand" style="font-size:14px;line-height:20px;font-weight:500;">€6.35</span>
                            <div class="ds-spec-type__meta"><strong>body-md-accent</strong><code>14px / 20px / 500</code><code>color #8f4570</code></div>
                        </div>
                        <div class="ds-spec-type">
                            <span class="ds-spec-type__sample ds-spec-type__sample--strike" style="font-size:14px;line-height:20px;font-weight:400;">€24.90</span>
                            <div class="ds-spec-type__meta"><strong>body-md-muted</strong><code>14px / 20px / 400</code><code>color #9ca3af</code></div>
                        </div>
                        <div class="ds-spec-type">
                            <span class="ds-spec-type__sample" style="font-size:12px;line-height:16px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;">Sort</span>
                            <div class="ds-spec-type__meta"><strong>label-sm</strong><code>12px / 16px / 700</code><code>uppercase +1.2px</code></div>
                        </div>
                        <div class="ds-spec-type">
                            <span class="ds-spec-type__sample" style="font-size:10px;line-height:15px;font-weight:500;color:#111827;">Cart</span>
                            <div class="ds-spec-type__meta"><strong>label-xs</strong><code>10px / 15px / 500</code><code>inactive #a5abb0</code></div>
                        </div>
                    </div>
                </div>

                <div class="ds-spec__grid ds-spec__grid--2">
                    <div class="ds-spec__block">
                        <div class="ds-spec__block-head">
                            <p class="ds-spec__block-title">Spacing scale</p>
                            <p class="ds-spec__block-note">8px base unit</p>
                        </div>
                        <div class="ds-spec__block-body">
                            <div class="ds-spec-spacing">
                                <div class="ds-spec-spacing__row">
                                    <span class="ds-spec-spacing__label">XS</span>
                                    <div class="ds-spec-spacing__bar-wrap"><span class="ds-spec-spacing__bar" style="width:8px;"></span></div>
                                    <span class="ds-spec-spacing__token">8px · pill gap</span>
                                </div>
                                <div class="ds-spec-spacing__row">
                                    <span class="ds-spec-spacing__label">SM</span>
                                    <div class="ds-spec-spacing__bar-wrap"><span class="ds-spec-spacing__bar" style="width:12px;"></span></div>
                                    <span class="ds-spec-spacing__token">12px · icon gap</span>
                                </div>
                                <div class="ds-spec-spacing__row">
                                    <span class="ds-spec-spacing__label">MD</span>
                                    <div class="ds-spec-spacing__bar-wrap"><span class="ds-spec-spacing__bar" style="width:16px;"></span></div>
                                    <span class="ds-spec-spacing__token">16px · screen pad</span>
                                </div>
                                <div class="ds-spec-spacing__row">
                                    <span class="ds-spec-spacing__label">LG</span>
                                    <div class="ds-spec-spacing__bar-wrap"><span class="ds-spec-spacing__bar" style="width:24px;"></span></div>
                                    <span class="ds-spec-spacing__token">24px · card stack</span>
                                </div>
                                <div class="ds-spec-spacing__row">
                                    <span class="ds-spec-spacing__label">XL</span>
                                    <div class="ds-spec-spacing__bar-wrap"><span class="ds-spec-spacing__bar" style="width:25px;"></span></div>
                                    <span class="ds-spec-spacing__token">25px · banner pad</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="ds-spec__block">
                        <div class="ds-spec__block-head">
                            <p class="ds-spec__block-title">Radius tokens</p>
                            <p class="ds-spec__block-note">corner cuts</p>
                        </div>
                        <div class="ds-spec__block-body">
                            <div class="ds-spec-radius">
                                <div class="ds-spec-radius__item">
                                    <span class="ds-spec-radius__shape ds-spec-radius__shape--r8"></span>
                                    <span class="ds-spec-radius__label">8px · icon box</span>
                                </div>
                                <div class="ds-spec-radius__item">
                                    <span class="ds-spec-radius__shape ds-spec-radius__shape--r12"></span>
                                    <span class="ds-spec-radius__label">12px · cards + CTAs</span>
                                </div>
                                <div class="ds-spec-radius__item">
                                    <span class="ds-spec-radius__shape ds-spec-radius__shape--pill"></span>
                                    <span class="ds-spec-radius__label">9999px · pills</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `
    },
    cta: {
        title: 'CTA hierarchy',
        html: `
            <div class="ds-spec">
                <p class="ds-spec-rule"><strong>Rule:</strong> One filled primary button per screen. Secondary actions stay outlined or low contrast so users always know what to tap next.</p>
                <div class="ds-spec__grid ds-spec__grid--2 ds-spec__grid--btn-comps">
                    ${dsBtnComp({
                        token: 'btn-secondary',
                        label: 'Go to cart',
                        specImage: './assets/design-specs/btn-secondary.png',
                        specAlt: 'Go to cart button spec with 16px vertical padding and full width',
                        props: [
                            ['type', 'outline'],
                            ['width', 'fill'],
                            ['pad', '16px vertical'],
                            ['radius', '12px'],
                            ['text', '15px / 500']
                        ]
                    })}
                    ${dsBtnComp({
                        token: 'btn-primary-pdp',
                        label: 'Add to cart',
                        specImage: './assets/design-specs/btn-primary-pdp.png',
                        specAlt: 'Add to cart button spec with 16px vertical padding and full width',
                        props: [
                            ['type', 'filled'],
                            ['width', 'fill'],
                            ['pad', '16px vertical'],
                            ['fill', '#000000'],
                            ['text', '16px / 700']
                        ]
                    })}
                </div>
            </div>
        `
    },
    components: {
        title: 'Components & icons',
        html: `
            <div class="ds-spec">
                <div class="ds-spec__grid ds-spec__grid--3 ds-spec__grid--comp-specs">
                ${dsCompSpec({
                    token: 'nav-tab-bar',
                    label: 'Tab bar',
                    context: 'Every screen',
                    specImage: './assets/design-specs/nav-tab-bar.png',
                    specAlt: 'Tab bar spec with 24px vertical padding, 36px side padding, and full width',
                    props: [
                        ['width', 'fill'],
                        ['pad', '24×36'],
                        ['gap', '4px icon-label'],
                        ['label', 'label-xs'],
                        ['badge', '#fbcfe8']
                    ]
                })}

                ${dsCompSpec({
                    token: 'chip-category',
                    label: 'Category chips',
                    context: 'Homepage sub-nav',
                    specImage: './assets/design-specs/chip-category.png',
                    specAlt: 'Category chip spec with 12px vertical padding and 8px gap between pills',
                    props: [
                        ['pad', '12px vertical'],
                        ['pill pad', '6×12'],
                        ['gap', '8px'],
                        ['radius', 'pill'],
                        ['text', '12px / 500']
                    ]
                })}

                ${dsCompSpec({
                    token: 'card-cart-row',
                    label: 'Cart cards',
                    context: 'Session banner + wishlist',
                    specImage: './assets/design-specs/card-cart-row.png',
                    specAlt: 'Cart banner and wishlist row spec with 36px and 16px inset spacing',
                    props: [
                        ['banner inset', '36px'],
                        ['icon gap', '12px'],
                        ['stack gap', '36px'],
                        ['row pad', '16px'],
                        ['radius', '12px']
                    ]
                })}
                </div>
            </div>
        `
    },
    colors: {
        title: 'Color system',
        html: `
            <div class="ds-spec">
                <div class="ds-spec__grid ds-spec__grid--2">
                    <div class="ds-color-spec">
                        <div class="ds-color-spec__head">
                            <p class="ds-color-spec__title">Brand</p>
                            <p class="ds-color-spec__note">Accent + highlights</p>
                        </div>
                        <div class="ds-color-spec__body">
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip" style="background:#8f4570;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>primary</strong>
                                    <code>#8f4570</code>
                                    <span>Discount, heart icon, guide labels</span>
                                </div>
                            </div>
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip" style="background:#ffa4d4;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>primary-container</strong>
                                    <code>#ffa4d4</code>
                                    <span>Card icon backgrounds</span>
                                </div>
                            </div>
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip" style="background:#ffd0e5;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>secondary-container</strong>
                                    <code>#ffd0e5</code>
                                    <span>Spec panel accents</span>
                                </div>
                            </div>
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip" style="background:#fbcfe8;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>badge-pink</strong>
                                    <code>#fbcfe8</code>
                                    <span>Cart tab badge</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="ds-color-spec">
                        <div class="ds-color-spec__head">
                            <p class="ds-color-spec__title">Surface</p>
                            <p class="ds-color-spec__note">Backgrounds + cards</p>
                        </div>
                        <div class="ds-color-spec__body">
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip ds-color-swatch__chip--border" style="background:#ffffff;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>surface-card</strong>
                                    <code>#ffffff</code>
                                    <span>Cards, tab bar, inputs</span>
                                </div>
                            </div>
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip ds-color-swatch__chip--border" style="background:#fff8f8;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>surface</strong>
                                    <code>#fff8f8</code>
                                    <span>Case study + app base</span>
                                </div>
                            </div>
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip ds-color-swatch__chip--border" style="background:#fff0f4;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>surface-low</strong>
                                    <code>#fff0f4</code>
                                    <span>Guide card, wishlist circle</span>
                                </div>
                            </div>
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip" style="background:#f5f5f5;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>surface-muted</strong>
                                    <code>#f5f5f5</code>
                                    <span>Cart screen background</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="ds-spec__grid ds-spec__grid--2">
                    <div class="ds-color-spec">
                        <div class="ds-color-spec__head">
                            <p class="ds-color-spec__title">Text</p>
                            <p class="ds-color-spec__note">Type hierarchy</p>
                        </div>
                        <div class="ds-color-spec__body">
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip" style="background:#111827;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>text-primary</strong>
                                    <code>#111827</code>
                                    <span>Titles, prices, active nav</span>
                                </div>
                            </div>
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip" style="background:#6b7280;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>text-secondary</strong>
                                    <code>#6b7280</code>
                                    <span>Summary labels, hints</span>
                                </div>
                            </div>
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip" style="background:#9ca3af;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>text-muted</strong>
                                    <code>#9ca3af</code>
                                    <span>Size, struck-through price</span>
                                </div>
                            </div>
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip" style="background:#a5abb0;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>text-inactive</strong>
                                    <code>#a5abb0</code>
                                    <span>Inactive tab labels</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="ds-color-spec">
                        <div class="ds-color-spec__head">
                            <p class="ds-color-spec__title">Action + UI</p>
                            <p class="ds-color-spec__note">CTAs + chrome</p>
                        </div>
                        <div class="ds-color-spec__body">
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip" style="background:#000000;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>action-primary</strong>
                                    <code>#000000</code>
                                    <span>Checkout, Add to cart, headers</span>
                                </div>
                            </div>
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip ds-color-swatch__chip--border" style="background:#ffffff; border-color:#d1d5db;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>action-secondary</strong>
                                    <code>#d1d5db border</code>
                                    <span>Go to cart outline</span>
                                </div>
                            </div>
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip ds-color-swatch__chip--border" style="background:#ffffff; border-color:#f3f4f6;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>border-subtle</strong>
                                    <code>#f3f4f6</code>
                                    <span>Card edges, tab bar top</span>
                                </div>
                            </div>
                            <div class="ds-color-swatch">
                                <span class="ds-color-swatch__chip ds-color-swatch__chip--border" style="background:#f3f4f6;"></span>
                                <div class="ds-color-swatch__meta">
                                    <strong>icon-surface</strong>
                                    <code>#f3f4f6</code>
                                    <span>Session banner icon box</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="ds-color-usage">
                    <p class="ds-color-usage__label">Usage in prototype</p>
                    <div class="ds-color-usage__row">
                        <span class="ds-color-usage__chip" style="background:#8f4570;">primary</span>
                        <span class="ds-color-usage__arrow" aria-hidden="true">→</span>
                        <span class="ds-color-usage__text">Discount row, wishlist heart, active guide card</span>
                    </div>
                    <div class="ds-color-usage__row">
                        <span class="ds-color-usage__chip ds-color-usage__chip--dark">#000</span>
                        <span class="ds-color-usage__arrow" aria-hidden="true">→</span>
                        <span class="ds-color-usage__text">One filled CTA per screen + screen headers</span>
                    </div>
                    <div class="ds-color-usage__row">
                        <span class="ds-color-usage__chip ds-color-usage__chip--light">#fff0f4</span>
                        <span class="ds-color-usage__arrow" aria-hidden="true">→</span>
                        <span class="ds-color-usage__text">Soft brand surfaces behind icons and guide content</span>
                    </div>
                </div>
            </div>
        `
    }
};

function renderDesignSystemDetail(topicId) {
    const panel = designSystemPanels[topicId];
    const titleEl = document.getElementById('design-system-detail-title');
    const contentEl = document.getElementById('design-system-detail-content');
    if (!panel || !titleEl || !contentEl) return;

    titleEl.textContent = panel.title;
    contentEl.innerHTML = panel.html;
}

const designSystemCards = document.querySelectorAll('.design-system-card');

designSystemCards.forEach(card => {
    card.addEventListener('click', () => {
        const topicId = card.dataset.designTopic;
        designSystemCards.forEach(c => {
            c.classList.remove('design-system-card--active');
            c.setAttribute('aria-pressed', 'false');
        });
        card.classList.add('design-system-card--active');
        card.setAttribute('aria-pressed', 'true');
        renderDesignSystemDetail(topicId);
    });
});

if (designSystemCards.length) {
    renderDesignSystemDetail('typography');
}
